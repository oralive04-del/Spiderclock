# Spider Clock - Build APK lewat GitHub Actions

Project ini berisi Spider Clock dengan alarm Android native. Alarm dijadwalkan memakai AlarmManager sehingga dapat dipicu oleh sistem meskipun aplikasi tidak sedang terbuka. Pada Android 12+ izin alarm tepat dapat perlu diaktifkan oleh pengguna.

## Cara build dari HP
1. Buat repository GitHub baru, misalnya `SpiderClock`.
2. Upload semua isi folder `SpiderClock` ini ke repository. Pastikan `settings.gradle` berada di root repository, bukan di dalam folder tambahan.
3. Buka tab **Actions**.
4. Pilih workflow **Build Spider Clock APK**.
5. Tekan **Run workflow** jika belum otomatis berjalan.
6. Setelah selesai, buka hasil workflow dan bagian **Artifacts**.
7. Download `SpiderClock-debug-apk`.
8. Ekstrak ZIP artifact, lalu install `app-debug.apk` di Android.

## Izin alarm
Saat pertama memasang alarm, Android dapat meminta izin **Alarm & reminders / Alarms & reminders** untuk exact alarm. Berikan izin tersebut agar alarm dapat dijadwalkan tepat waktu.
