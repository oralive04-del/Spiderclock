package com.spiderclock.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;

public class AlarmService extends Service {
    private static final String CHANNEL_ID = "spider_alarm";
    private MediaPlayer player;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Intent stop = new Intent(this, StopAlarmReceiver.class);
        PendingIntent stopPi = PendingIntent.getBroadcast(this, 99, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("⏰ Spider Clock").setContentText("Alarm sedang berbunyi").setOngoing(true).setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX).addAction(new Notification.Action.Builder(0, "Hentikan", stopPi).build());
        startForeground(7, b.build());
        player = MediaPlayer.create(this, com.spiderclock.app.R.raw.alarm);
        if (player != null) {
            player.setLooping(true);
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.start();
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL_ID, "Alarm Spider Clock", NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("Alarm dari Spider Clock");
            c.setSound(null, null);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_NOT_STICKY; }

    @Override public void onDestroy() {
        if (player != null) { if (player.isPlaying()) player.stop(); player.release(); player = null; }
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
