# Spider Clock - Alarm Android

Project ini memakai `index.html` + `alarm.mp3` milik pengguna dan menambahkan alarm Android native.

Fitur:
- Alarm dijadwalkan dengan AlarmManager.
- `setExactAndAllowWhileIdle()` agar alarm tetap dapat dibangunkan saat idle.
- `BroadcastReceiver` menerima alarm.
- Foreground service memutar `alarm.mp3` berulang.
- Tombol Hentikan di notifikasi menghentikan bunyi.
- HTML tetap punya fallback alarm saat dibuka di browser.

## Cara build
1. Buka folder `SpiderClock` dengan Android Studio.
2. Sync Gradle.
3. Build > Build APK(s).
4. Install APK.
5. Saat pertama kali diminta, izinkan notifikasi dan izin alarm tepat.

Catatan: beberapa HP Android memiliki penghemat baterai yang dapat membatasi alarm. Jika alarm tidak jalan, izinkan Spider Clock berjalan tanpa pembatasan baterai di pengaturan baterai HP.
